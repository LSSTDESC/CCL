#Global variables
fgrow=''
kmin=[]
kmax=[]
zvec=[]
chivec=[]
dndzfunc=[]
wb=[]
wbtmp=[]
subwg=[]
chilensglob=[]
psnorm=[]
chimax=[]
zmax=[]
